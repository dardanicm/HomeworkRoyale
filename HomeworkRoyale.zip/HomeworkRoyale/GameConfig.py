TILE_SIZE      = 64
GRID_WIDTH     = 12
GRID_HEIGHT    = 9
SCREEN_WIDTH   = TILE_SIZE * GRID_WIDTH
SCREEN_HEIGHT  = TILE_SIZE * GRID_HEIGHT

# Available cards
card_names = ["Knight", "Archer", "Wizard", "Giant", "MegaKnight"]

CARD_COSTS = {
    "Knight":      2,
    "Archer":      3,
    "Wizard":      5,
    "Giant":       6,
    "MegaKnight":  7,
}

# Unit stats (tiles/sec and seconds)
UNIT_STATS = {
    "Knight":     dict(health=100, damage=25, range=1, atk_speed=0.8, move_speed=0.6),
    "Archer":     dict(health= 70, damage=20, range=3, atk_speed=1.0, move_speed=0.5),
    "Wizard":     dict(health= 80, damage=35, range=3, atk_speed=1.2, move_speed=0.5),
    "Giant":      dict(health=300, damage=40, range=1, atk_speed=1.5, move_speed=0.4),
    "MegaKnight": dict(health=350, damage=50, range=1, atk_speed=1.2, move_speed=0.45),
    "Princess":   dict(health=250, damage=15, range=4, atk_speed=1.0, move_speed=0.0),
    "King":       dict(health=500, damage=25, range=4, atk_speed=0.9, move_speed=0.0),
}

# Map layout
RIVER_COLS  = (GRID_WIDTH // 2 - 1, GRID_WIDTH // 2)
BRIDGE_ROWS = (GRID_HEIGHT // 3, GRID_HEIGHT * 2 // 3)

def is_water(tx:int, ty:int) -> bool:
    return tx in RIVER_COLS and ty not in BRIDGE_ROWS

def is_passable(tx:int, ty:int) -> bool:
    return 0 <= tx < GRID_WIDTH and 0 <= ty < GRID_HEIGHT and not is_water(tx, ty)

# Game timing and logic
REGULATION_SEC   = 120
OVERTIME_SEC     = 60
ELIXIR_INT_EARLY = 2.8
ELIXIR_INT_LATE  = 1.4
ELIXIR_LIMIT     = 10
MAX_SIDE_UNITS   = 10

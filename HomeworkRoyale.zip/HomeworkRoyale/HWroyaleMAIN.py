# HWroyaleMAIN.py — Final Build by Dardan & Copilot

import pygame, random, pathlib, sys, math
import GameConfig as cfg
from itertools import count

# ───────────── Init
pygame.init()
screen = pygame.display.set_mode((cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT))
pygame.display.set_caption("HomeworkRoyale")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 24)
vec = pygame.math.Vector2

# ───────────── Load assets
def load_sprite(tag, size=cfg.TILE_SIZE):
    p = pathlib.Path("Assets") / f"{tag}ClashRoyale.png"
    if p.exists():
        return pygame.transform.smoothscale(pygame.image.load(p).convert_alpha(), (size, size))
    s = pygame.Surface((size, size)); s.fill((200, 50, 50)); pygame.draw.rect(s, (0, 0, 0), s.get_rect(), 2); return s

unit_img   = {n: load_sprite(n) for n in cfg.UNIT_STATS}
terrain    = {"water": pygame.Surface((cfg.TILE_SIZE,cfg.TILE_SIZE)), "bridge": load_sprite("Bridge")}
terrain["water"].fill((0,100,255))
teacher_ic = load_sprite("Teacher", 60)
menu_ic    = pygame.Surface((60, 60)); menu_ic.fill((100,100,150)); pygame.draw.rect(menu_ic, (255,255,255), menu_ic.get_rect(), 2)
pygame.draw.polygon(menu_ic, (255,255,255), [(15,30),(45,15),(45,45)])
teacher_rc = teacher_ic.get_rect(topright=(cfg.SCREEN_WIDTH-10, 10))
menu_rc    = menu_ic.get_rect(topright=(teacher_rc.left - 10, 10))
hw_img     = load_sprite("Calculus", size=cfg.SCREEN_HEIGHT)
laugh_img  = load_sprite("Laugh", size=160)

class Scene: MENU = 0; GAME = 1
scene = Scene.MENU
phase, timer, winner = 0, cfg.REGULATION_SEC, None
pl_elixir = ai_elixir = 10
pl_cd = ai_cd = cfg.ELIXIR_INT_EARLY
selected_ix = 0
homework = False

player_units, enemy_units, projectiles = [], [], []
player_towers, enemy_towers = [], []

# ───────────── Units & Projectiles
PROJECTILE_SPEED = 5.0
SPLASH_RADIUS = 0.6

class Unit:
    _ids = count(0)
    def __init__(self, name, tx, ty, enemy=False):
        self.id = next(Unit._ids); self.name = name
        self.stats = cfg.UNIT_STATS[name]; self.image = unit_img[name]
        self.tx, self.ty = tx, ty
        self.px, self.py = (tx+0.5)*cfg.TILE_SIZE, (ty+0.5)*cfg.TILE_SIZE
        self.enemy = enemy; self.health = self.stats["health"]
        self.cool = self.move_prog = 0.0

    def update(self, dt, allies, foes, projs):
        if self.health <= 0: return
        self.cool = max(0, self.cool - dt)
        pool = [f for f in foes if f.health > 0]
        pool = [t for t in pool if not (t.name == "King" and not king_vulnerable(t.enemy))]
        tgt = min(pool, key=lambda o: abs(o.tx-self.tx)+abs(o.ty-self.ty), default=None)
        if tgt:
            dx, dy = tgt.tx - self.tx, tgt.ty - self.ty
            dist = abs(dx) + abs(dy)
            if dist <= self.stats["range"]:
                if self.cool == 0:
                    if self.name == "Archer": projs.append(Arrow(self,tgt))
                    elif self.name == "Wizard": projs.append(Fireball(self,tgt))
                    else: tgt.health -= self.stats["damage"]
                    self.cool = self.stats["atk_speed"]
                return
            if self.name == "MegaKnight" and dist == 1 and cfg.is_passable(tgt.tx, tgt.ty):
                self.tx, self.ty = tgt.tx, tgt.ty
                self.px, self.py = (self.tx+0.5)*cfg.TILE_SIZE, (self.ty+0.5)*cfg.TILE_SIZE
                return
        if self.stats["move_speed"] == 0 or phase == 2 or homework: return
        self.move_prog += self.stats["move_speed"] * dt
        while self.move_prog >= 1.0:
            self.move_prog -= 1.0
            nx, ny = self.next_tile()
            if cfg.is_passable(nx, ny): self.tx, self.ty = nx, ny
            else: break
        self.px, self.py = (self.tx+0.5)*cfg.TILE_SIZE, (self.ty+0.5)*cfg.TILE_SIZE

    def next_tile(self):
        dx = 1 if not self.enemy else -1
        if not cfg.is_passable(self.tx+dx, self.ty):
            bridge = cfg.BRIDGE_ROWS[0] if self.ty < cfg.GRID_HEIGHT//2 else cfg.BRIDGE_ROWS[1]
            dy = 1 if bridge > self.ty else -1
            return self.tx, self.ty + dy
        return self.tx+dx, self.ty

    def draw(self):
        rect = self.image.get_rect(center=(self.px,self.py))
        screen.blit(self.image, rect)
        ratio = max(0, self.health/self.stats["health"])
        col = (0,255,0) if not self.enemy else (255,215,0)
        pygame.draw.rect(screen, (60,60,60), (rect.left, rect.top-6, cfg.TILE_SIZE, 4))
        pygame.draw.rect(screen, col, (rect.left, rect.top-6, cfg.TILE_SIZE * ratio, 4))

class Tower(Unit): pass

class Arrow:
    color = (150,150,150)
    def __init__(self, src, tgt):
        self.px, self.py = src.px, src.py
        dir_vec = vec(tgt.px-src.px, tgt.py-src.py)
        if dir_vec.length() == 0: dir_vec = vec(random.uniform(-1,1), random.uniform(-1,1))
        self.vel = dir_vec.normalize() * PROJECTILE_SPEED * cfg.TILE_SIZE
        self.dmg = src.stats["damage"]; self.enemy = src.enemy; self.alive = True
    def update(self, dt, foes):
        if not self.alive: return
        self.px += self.vel.x * dt; self.py += self.vel.y * dt
        if not (0 <= self.px < cfg.SCREEN_WIDTH and 0 <= self.py < cfg.SCREEN_HEIGHT): self.alive = False; return
        for f in foes:
            if f.health > 0 and abs(f.px-self.px)<cfg.TILE_SIZE*0.3 and abs(f.py-self.py)<cfg.TILE_SIZE*0.3:
                f.health -= self.dmg; self.alive=False; return
    def draw(self): pygame.draw.circle(screen,self.color,(int(self.px),int(self.py)),4)

class Fireball(Arrow):
    color = (255,90,0)
    def update(self, dt, foes):
        if not self.alive: return
        self.px += self.vel.x * dt; self.py += self.vel.y * dt
        if not (0 <= self.px < cfg.SCREEN_WIDTH and 0 <= self.py < cfg.SCREEN_HEIGHT): self.alive = False; return
        for f in foes:
            if f.health > 0 and abs(f.px-self.px)<cfg.TILE_SIZE*0.3 and abs(f.py-self.py)<cfg.TILE_SIZE*0.3:
                for g in foes:
                    if math.hypot(g.px-self.px, g.py-self.py) <= SPLASH_RADIUS * cfg.TILE_SIZE:
                        g.health -= self.dmg
                self.alive = False; return
    def draw(self): pygame.draw.circle(screen,self.color,(int(self.px),int(self.py)),6)

#  Remaining functions — event loop, UI, AI, overtime tiebreaker — continue right after this block.
def king_vulnerable(side):
    towers = enemy_towers if side else player_towers
    return any(t.health <= 0 for t in towers if t.name == "Princess")


def mmss(sec): return f"{int(sec)//60}:{int(sec)%60:02d}"

def advance_elixir(dt):
    global pl_elixir, ai_elixir, pl_cd, ai_cd
    interval = cfg.ELIXIR_INT_EARLY if phase == 0 else cfg.ELIXIR_INT_LATE
    pl_cd -= dt; ai_cd -= dt
    if pl_cd <= 0:
        if pl_elixir < cfg.ELIXIR_LIMIT: pl_elixir += 1
        pl_cd += interval
    if ai_cd <= 0:
        if ai_elixir < cfg.ELIXIR_LIMIT: ai_elixir += 1
        ai_cd += interval

def place_unit(name, tx, ty):
    global pl_elixir
    if tx >= cfg.GRID_WIDTH // 2 or not cfg.is_passable(tx, ty): return
    if pl_elixir < cfg.CARD_COSTS[name]: return
    if len([u for u in player_units if u.health > 0 and not isinstance(u, Tower)]) >= cfg.MAX_SIDE_UNITS: return
    pl_elixir -= cfg.CARD_COSTS[name]
    player_units.append(Unit(name, tx, ty))

def ai_try_spawn(dt):
    global ai_elixir
    if len([u for u in enemy_units if u.health > 0 and not isinstance(u, Tower)]) >= cfg.MAX_SIDE_UNITS: return
    if random.random() < 0.02 * dt * 60:
        name = random.choice(cfg.card_names)
        cost = cfg.CARD_COSTS[name]
        if ai_elixir < cost: return
        for _ in range(20):
            tx = random.randint(cfg.GRID_WIDTH//2, cfg.GRID_WIDTH - 1)
            ty = random.randint(0, cfg.GRID_HEIGHT - 1)
            if cfg.is_passable(tx, ty):
                enemy_units.append(Unit(name, tx, ty, True))
                ai_elixir -= cost
                break

def draw_map():
    for tx in range(cfg.GRID_WIDTH):
        for ty in range(cfg.GRID_HEIGHT):
            if cfg.is_water(tx, ty): screen.blit(terrain["water"], (tx*cfg.TILE_SIZE, ty*cfg.TILE_SIZE))
            elif tx in cfg.RIVER_COLS and ty in cfg.BRIDGE_ROWS:
                screen.blit(terrain["bridge"], (tx*cfg.TILE_SIZE, ty*cfg.TILE_SIZE))

def draw_grid():
    for x in range(0, cfg.SCREEN_WIDTH, cfg.TILE_SIZE): pygame.draw.line(screen, (50,50,50), (x,0), (x,cfg.SCREEN_HEIGHT))
    for y in range(0, cfg.SCREEN_HEIGHT, cfg.TILE_SIZE): pygame.draw.line(screen, (50,50,50), (0,y), (cfg.SCREEN_WIDTH,y))

def draw_ui():
    ttxt = font.render(mmss(timer), True, (255,255,255))
    screen.blit(ttxt, (10,5))
    if phase == 1 and winner is None:
        otxt = font.render("Overtime", True, (255,165,0))
        screen.blit(otxt, (10 + ttxt.get_width() + 8, 5))
    etxt = font.render(f"Elixir: {pl_elixir}", True, (255,255,0))
    screen.blit(etxt, (10,28))
    screen.blit(teacher_ic, teacher_rc)
    screen.blit(menu_ic, menu_rc)
    for i, name in enumerate(cfg.card_names):
        bx = i * 80
        pygame.draw.rect(screen, (80,80,80), (bx, cfg.SCREEN_HEIGHT-70, 78, 68))
        thumb = pygame.transform.smoothscale(unit_img[name], (48,48))
        screen.blit(thumb, (bx+15, cfg.SCREEN_HEIGHT-65))
        cost = font.render(str(cfg.CARD_COSTS[name]), True, (255,255,255))
        screen.blit(cost, (bx+30, cfg.SCREEN_HEIGHT-22))
        if i == selected_ix:
            pygame.draw.rect(screen, (255,215,0), (bx, cfg.SCREEN_HEIGHT - 70, 78, 68), 3)

def draw_menu():
    screen.fill((30,30,60))
    title = font.render("Homework Royale", True, (255,255,255))
    screen.blit(title, (cfg.SCREEN_WIDTH//2 - title.get_width()//2, 80))
    play_rect = pygame.Rect(cfg.SCREEN_WIDTH//2 - 100, 180, 200, 50)
    exit_rect = pygame.Rect(cfg.SCREEN_WIDTH//2 - 100, 260, 200, 50)
    pygame.draw.rect(screen, (80,120,200), play_rect)
    pygame.draw.rect(screen, (200,60,60), exit_rect)
    screen.blit(font.render("Play", True, (255,255,255)), (play_rect.centerx - 20, play_rect.centery - 12))
    screen.blit(font.render("Exit", True, (255,255,255)), (exit_rect.centerx - 20, exit_rect.centery - 12))
    return play_rect, exit_rect

def draw_result():
    shade = pygame.Surface((cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT), pygame.SRCALPHA)
    shade.fill((0, 0, 0, 180))
    screen.blit(shade, (0, 0))
    txt = font.render("Draw!" if winner=="Draw" else ("Victory!" if winner=="Player" else "Lost!"), True, (255,255,255))
    screen.blit(txt, (cfg.SCREEN_WIDTH//2 - txt.get_width()//2, 100))
    if winner == "Player":
        screen.blit(laugh_img, laugh_img.get_rect(center=(cfg.SCREEN_WIDTH//2, 240)))

# ───────────── Main loop
running = True
while running:
    dt = clock.tick(60) / 1000
    mx, my = pygame.mouse.get_pos()
    for ev in pygame.event.get():
        if ev.type == pygame.QUIT: running = False
        elif scene == Scene.MENU and ev.type == pygame.MOUSEBUTTONDOWN:
            play_btn, exit_btn = draw_menu()
            if play_btn.collidepoint(ev.pos):
                scene = Scene.GAME; phase = 0; winner = None; timer = cfg.REGULATION_SEC
                pl_elixir = ai_elixir = 10; pl_cd = ai_cd = cfg.ELIXIR_INT_EARLY
                player_units.clear(); enemy_units.clear(); projectiles.clear()
                player_towers[:] = [Tower("King", 0, 4), Tower("Princess", 0, 2), Tower("Princess", 0, 6)]
                enemy_towers[:]  = [Tower("King", cfg.GRID_WIDTH-1, 4, True), Tower("Princess", cfg.GRID_WIDTH-1, 2, True), Tower("Princess", cfg.GRID_WIDTH-1, 6, True)]
                player_units.extend(player_towers); enemy_units.extend(enemy_towers)
            elif exit_btn.collidepoint(ev.pos):
                running = False
        elif scene == Scene.GAME and ev.type == pygame.MOUSEBUTTONDOWN:
            if teacher_rc.collidepoint(ev.pos): homework = not homework
            elif menu_rc.collidepoint(ev.pos): scene = Scene.MENU
            elif not homework and winner is None:
                place_unit(cfg.card_names[selected_ix], mx // cfg.TILE_SIZE, my // cfg.TILE_SIZE)
        elif ev.type == pygame.KEYDOWN and scene == Scene.GAME and not homework:
            if ev.key == pygame.K_RIGHT: selected_ix = (selected_ix + 1) % len(cfg.card_names)
            elif ev.key == pygame.K_LEFT: selected_ix = (selected_ix - 1) % len(cfg.card_names)

    if scene == Scene.MENU:
        draw_menu()
    elif scene == Scene.GAME:
        if not homework and phase != 2:
            timer -= dt
            timer = max(0, timer)
            if phase == 1 and timer > 0:
                pt = sum(t.health > 0 for t in player_towers if t.name == "Princess")
                et = sum(t.health > 0 for t in enemy_towers  if t.name == "Princess")
                if pt > et: winner = "Player"; phase = 2
                elif et > pt: winner = "AI"; phase = 2
            if timer <= 0:
                if phase == 0:
                    pt = sum(t.health > 0 for t in player_towers if t.name == "Princess")
                    et = sum(t.health > 0 for t in enemy_towers  if t.name == "Princess")
                    if pt > et: winner = "Player"; phase = 2
                    elif et > pt: winner = "AI"; phase = 2
                    else: phase = 1; timer = cfg.OVERTIME_SEC
                else:
                    p_hp = sum(t.health for t in player_towers if t.name == "Princess")
                    e_hp = sum(t.health for t in enemy_towers if t.name == "Princess")
                    if p_hp > e_hp: winner = "Player"
                    elif e_hp > p_hp: winner = "AI"
                    else: winner = "Draw"
                    phase = 2

            advance_elixir(dt)
            ai_try_spawn(dt)

            player_units[:] = [u for u in player_units if u.health > 0]
            enemy_units[:]  = [u for u in enemy_units  if u.health > 0]
            projectiles[:]  = [p for p in projectiles  if p.alive]

            for p in projectiles:
                p.update(dt, enemy_units if not p.enemy else player_units)

            for group in (player_units, enemy_units):
                for u in group:
                    u.update(dt,
                             player_units if not u.enemy else enemy_units,
                             enemy_units if not u.enemy else player_units,
                             projectiles)

            if player_towers[0].health <= 0: winner = "AI"; phase = 2
            if enemy_towers[0].health  <= 0: winner = "Player"; phase = 2

        # ───────────── Draw
        screen.fill((34,139,34))
        draw_map()
        draw_grid()
        for group in (player_units, enemy_units):
            for u in group:
                u.draw()
        for p in projectiles:
            p.draw()
        draw_ui()

        if homework:
            screen.fill((255,255,255))
            screen.blit(hw_img, hw_img.get_rect(center=(cfg.SCREEN_WIDTH//2, cfg.SCREEN_HEIGHT//2)))
            screen.blit(teacher_ic, teacher_rc)
            screen.blit(menu_ic, menu_rc)
        elif phase == 2:
            draw_result()

    pygame.display.flip()

pygame.quit()
sys.exit()
